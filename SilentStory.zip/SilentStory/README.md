# Silent Story

Android app (Kotlin + Jetpack Compose) for viewing Instagram stories without marking them as seen.

## Features
- In-app Instagram login (session cookie stays on the device)
- Search any username, view active stories and highlights
- "New stories" row from accounts you follow
- Pinned profiles grid
- Full-screen viewer (images and video), swipe between stories
- Save to gallery (Pictures/SilentStory, Movies/SilentStory) and share
- The "seen" request is never sent, so viewing stays anonymous

## Build the APK
1. Install Android Studio (Koala or newer).
2. File > Open > select this folder, let Gradle sync finish.
3. Build > Build APK(s). The file is at `app/build/outputs/apk/debug/app-debug.apk`.
4. Copy it to your phone and install (allow "install unknown apps").

## Notes
- Uses Instagram's unofficial web endpoints (see `Data.kt`). They can change or be rate-limited.
  If stories stop loading, that file is the only place to update.
- Private accounts only work if the account you log in with follows them.
- This is not affiliated with Instagram. Use a secondary account if you worry about restrictions.
- Not suitable for Google Play (it breaks Instagram's terms); distribute the APK yourself.
