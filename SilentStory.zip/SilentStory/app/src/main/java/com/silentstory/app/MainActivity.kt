package com.silentstory.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val session = Session(this)

        // Saves the viewer list of your own stories about once an hour.
        val work = PeriodicWorkRequestBuilder<ViewerWorker>(1, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this)
            .enqueueUniquePeriodicWork("viewers", ExistingPeriodicWorkPolicy.KEEP, work)

        setContent { App(session) }
    }
}

sealed interface Overlay {
    data class ProfileO(val profile: Profile) : Overlay
    data class ViewerO(val items: List<StoryItem>, val start: Int, val owner: String) : Overlay
    data object Viewers : Overlay
    data object Membership : Overlay
    data object Accounts : Overlay
    data class Info(val title: String, val text: String) : Overlay
}

@Composable
fun App(session: Session) {
    var theme by remember { mutableStateOf(session.theme) }
    var lang by remember { mutableStateOf(session.lang) }
    val dark = when (theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val colors = if (dark) {
        darkColorScheme(primary = Pink, background = Color(0xFF121212), surface = Color(0xFF1E1E1E))
    } else {
        lightColorScheme(
            primary = Purple, background = Color(0xFFF2F2F7), surface = Color.White,
            surfaceVariant = Color.White,
        )
    }
    CompositionLocalProvider(LocalLang provides lang) {
        MaterialTheme(colorScheme = colors) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Root(
                    session, theme, lang,
                    onTheme = { theme = it; session.theme = it },
                    onLang = { lang = it; session.lang = it },
                )
            }
        }
    }
}

@Composable
fun Root(
    session: Session,
    theme: String,
    lang: String,
    onTheme: (String) -> Unit,
    onLang: (String) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var accountsVersion by remember { mutableIntStateOf(0) }
    var addingAccount by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    val stack = remember { mutableStateListOf<Overlay>() }

    val hasAccount = remember(accountsVersion) { session.accounts().isNotEmpty() }

    if (!hasAccount || addingAccount) {
        LoginScreen(
            fresh = addingAccount,
            onCancel = if (addingAccount) ({ addingAccount = false }) else null,
        ) { cookie ->
            scope.launch {
                val uid = Regex("ds_user_id=(\\d+)").find(cookie)?.groupValues?.get(1) ?: return@launch
                val name = runCatching { withContext(Dispatchers.IO) { Api.username(uid, cookie) } }
                    .getOrDefault("account $uid")
                session.addAccount(Account(uid, name, cookie))
                addingAccount = false
                accountsVersion++
            }
        }
        return
    }

    val accountKey = remember(accountsVersion) { session.active?.userId ?: "" }

    BackHandler(enabled = stack.isNotEmpty()) {
        stack.removeAt(stack.lastIndex)
        refresh++
    }

    fun openStories(p: Profile) {
        if (busy) return
        busy = true
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { Api.stories(p.id, session.cookie) } }
                .onSuccess { items ->
                    busy = false
                    if (items.isEmpty()) {
                        Toast.makeText(ctx, tr("no_stories", lang), Toast.LENGTH_SHORT).show()
                    } else {
                        session.setViewed(p.id, items.maxOf { it.takenAt })
                        stack.add(Overlay.ViewerO(items, 0, p.username))
                    }
                }
                .onFailure {
                    busy = false
                    Toast.makeText(ctx, it.message ?: "Error", Toast.LENGTH_LONG).show()
                }
        }
    }

    val top = stack.lastOrNull()
    Box(Modifier.fillMaxSize()) {
        if (top == null) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar {
                        listOf(
                            Triple("home", Icons.Default.Home, 0),
                            Triple("search", Icons.Default.Search, 1),
                            Triple("favorites", Icons.Default.Favorite, 2),
                            Triple("settings", Icons.Default.Settings, 3),
                        ).forEach { (key, icon, idx) ->
                            NavigationBarItem(
                                selected = tab == idx,
                                onClick = { tab = idx },
                                icon = { Icon(icon, null) },
                                label = { Text(tr(key, lang)) },
                            )
                        }
                    }
                },
            ) { pad ->
                Box(Modifier.padding(bottom = pad.calculateBottomPadding())) {
                    when (tab) {
                        0 -> HomeTab(session, accountKey, refresh) { u -> openStories(u.profile) }
                        1 -> SearchTab(session) { stack.add(Overlay.ProfileO(it)) }
                        2 -> FavoritesTab(session, refresh) { stack.add(Overlay.ProfileO(it)) }
                        else -> SettingsTab(session, accountKey, theme, lang, onTheme, onLang) { stack.add(it) }
                    }
                }
            }
        } else {
            val close = { stack.removeAt(stack.lastIndex); refresh++; Unit }
            when (top) {
                is Overlay.ProfileO -> ProfileScreen(
                    session, top.profile, onBack = close,
                    onOpenViewer = { items, i ->
                        session.setViewed(top.profile.id, items.maxOf { it.takenAt })
                        stack.add(Overlay.ViewerO(items, i, top.profile.username))
                    },
                )
                is Overlay.ViewerO -> ViewerScreen(top.items, top.start, top.owner, close)
                is Overlay.Viewers -> ViewersScreen(session, close)
                is Overlay.Membership -> MembershipScreen(close)
                is Overlay.Info -> InfoScreen(top.title, top.text, close)
                is Overlay.Accounts -> AccountsScreen(
                    session,
                    onAdd = { stack.removeAt(stack.lastIndex); addingAccount = true },
                    onChanged = { accountsVersion++ },
                    onBack = close,
                )
            }
        }

        if (busy) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(fresh: Boolean, onCancel: (() -> Unit)?, onLoggedIn: (String) -> Unit) {
    var done by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onCancel != null) {
                IconButton(onClick = onCancel) { Icon(Icons.Default.ArrowBack, "Back") }
            }
            Text(
                "Log in to Instagram",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(16.dp),
            )
        }
        Text(
            "Your login stays on this device. It is only sent to Instagram.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        AndroidView(
            modifier = Modifier.fillMaxSize().padding(top = 8.dp),
            factory = { ctx ->
                if (fresh) CookieManager.getInstance().removeAllCookies(null)
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String) {
                            val cookie = CookieManager.getInstance().getCookie("https://www.instagram.com") ?: ""
                            if (!done && cookie.contains("sessionid=") && cookie.contains("ds_user_id=")) {
                                done = true
                                onLoggedIn(cookie)
                            }
                        }
                    }
                    loadUrl("https://www.instagram.com/accounts/login/")
                }
            },
        )
    }
}
