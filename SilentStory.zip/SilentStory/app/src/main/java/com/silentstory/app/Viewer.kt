package com.silentstory.app

import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------- Profile ----------------

@Composable
fun ProfileScreen(
    session: Session,
    profile: Profile,
    onBack: () -> Unit,
    onOpenViewer: (List<StoryItem>, Int) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var stories by remember { mutableStateOf<List<StoryItem>?>(null) }
    var highlights by remember { mutableStateOf<List<Highlight>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var pinned by remember { mutableStateOf(session.isPinned(profile.id)) }

    LaunchedEffect(profile.id) {
        runCatching {
            withContext(Dispatchers.IO) {
                val st = Api.stories(profile.id, session.cookie)
                val hl = runCatching { Api.highlights(profile.id, session.cookie) }.getOrDefault(emptyList())
                st to hl
            }
        }.onSuccess { stories = it.first; highlights = it.second }
            .onFailure { error = it.message; stories = emptyList() }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            AsyncImage(
                model = profile.picUrl, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(44.dp).clip(CircleShape),
            )
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(profile.username, style = MaterialTheme.typography.titleMedium)
                if (profile.fullName.isNotBlank()) Text(profile.fullName, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = { session.togglePin(profile); pinned = !pinned }) {
                Icon(Icons.Default.Favorite, "Favorite", tint = if (pinned) Pink else Color.Gray)
            }
        }

        if (profile.isPrivate) {
            Text(
                "This account is private. Stories show only if the logged-in account follows it.",
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp),
            )
        }

        Text("Stories", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
        when {
            stories == null -> CircularProgressIndicator(Modifier.padding(16.dp))
            stories!!.isEmpty() -> Text(
                error ?: s("no_stories"), modifier = Modifier.padding(vertical = 8.dp),
                style = MaterialTheme.typography.bodySmall,
            )
            else -> LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.heightIn(max = 380.dp)) {
                items(stories!!.indices.toList()) { i ->
                    StoryThumb(stories!![i]) { onOpenViewer(stories!!, i) }
                }
            }
        }

        if (highlights.isNotEmpty()) {
            Text("Highlights", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp))
            LazyRow(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(highlights) { h ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(72.dp).clickable {
                            scope.launch {
                                runCatching {
                                    withContext(Dispatchers.IO) { Api.highlightItems(h.id, session.cookie) }
                                }.onSuccess { if (it.isNotEmpty()) onOpenViewer(it, 0) }
                                    .onFailure { Toast.makeText(ctx, it.message ?: "Error", Toast.LENGTH_SHORT).show() }
                            }
                        },
                    ) {
                        AsyncImage(
                            model = h.cover, contentDescription = h.title, contentScale = ContentScale.Crop,
                            modifier = Modifier.size(64.dp).clip(CircleShape).background(Color.LightGray),
                        )
                        Text(h.title, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
fun StoryThumb(item: StoryItem, onClick: () -> Unit) {
    Box(
        Modifier.padding(3.dp).aspectRatio(9f / 16f).clip(RoundedCornerShape(8.dp))
            .background(Color.DarkGray).clickable { onClick() },
    ) {
        AsyncImage(
            model = item.thumb, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        if (item.isVideo) {
            Icon(
                Icons.Default.PlayCircle, null, tint = Color.White,
                modifier = Modifier.align(Alignment.Center).size(32.dp),
            )
        }
    }
}

// ---------------- Full-screen viewer ----------------

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ViewerScreen(items: List<StoryItem>, start: Int, owner: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val pager = rememberPagerState(initialPage = start) { items.size }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            val item = items[page]
            if (item.isVideo) VideoPlayer(item.url, playing = pager.currentPage == page)
            else AsyncImage(
                model = item.url, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize(),
            )
        }

        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
            Text("$owner  ${pager.currentPage + 1}/${items.size}", color = Color.White, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                val item = items[pager.currentPage]
                scope.launch {
                    runCatching {
                        withContext(Dispatchers.IO) { Downloader.save(ctx, item, "${owner}_${System.currentTimeMillis()}") }
                    }.onSuccess { Toast.makeText(ctx, "Saved to gallery", Toast.LENGTH_SHORT).show() }
                        .onFailure { Toast.makeText(ctx, it.message ?: "Error", Toast.LENGTH_SHORT).show() }
                }
            }) { Icon(Icons.Default.Download, "Save", tint = Color.White) }
            IconButton(onClick = {
                val item = items[pager.currentPage]
                scope.launch {
                    runCatching { withContext(Dispatchers.IO) { Downloader.share(ctx, item) } }
                        .onFailure { Toast.makeText(ctx, it.message ?: "Error", Toast.LENGTH_SHORT).show() }
                }
            }) { Icon(Icons.Default.Share, "Share", tint = Color.White) }
        }
    }
}

@Composable
fun VideoPlayer(url: String, playing: Boolean) {
    val ctx = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            repeatMode = ExoPlayer.REPEAT_MODE_ONE
            prepare()
        }
    }
    LaunchedEffect(playing) { player.playWhenReady = playing }
    DisposableEffect(url) { onDispose { player.release() } }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { PlayerView(it).apply { this.player = player; useController = true } },
    )
}
