package com.silentstory.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException

object Downloader {
    private val client = OkHttpClient()

    /** Saves the story to Pictures/SilentStory or Movies/SilentStory. Returns the saved Uri. */
    fun save(context: Context, item: StoryItem, name: String): Uri {
        val ext = if (item.isVideo) "mp4" else "jpg"
        val mime = if (item.isVideo) "video/mp4" else "image/jpeg"
        val collection = if (item.isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val dir = if (item.isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.$ext")
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$dir/SilentStory")
        }
        val uri = context.contentResolver.insert(collection, values)
            ?: throw IOException("Could not create file")

        client.newCall(Request.Builder().url(item.url).build()).execute().use { res ->
            if (!res.isSuccessful) throw IOException("Download failed (${res.code})")
            context.contentResolver.openOutputStream(uri)?.use { out ->
                res.body?.byteStream()?.copyTo(out)
            }
        }
        return uri
    }

    /** Downloads to the cache folder and opens the system share sheet. */
    fun share(context: Context, item: StoryItem) {
        val ext = if (item.isVideo) "mp4" else "jpg"
        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        val file = File(dir, "story_${System.currentTimeMillis()}.$ext")
        client.newCall(Request.Builder().url(item.url).build()).execute().use { res ->
            if (!res.isSuccessful) throw IOException("Download failed (${res.code})")
            file.outputStream().use { out -> res.body?.byteStream()?.copyTo(out) }
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = if (item.isVideo) "video/mp4" else "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, "Share story").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
