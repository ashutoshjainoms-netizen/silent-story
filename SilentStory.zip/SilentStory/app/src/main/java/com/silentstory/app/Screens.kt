package com.silentstory.app

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Pink = Color(0xFFE0559A)
val Purple = Color(0xFF8E24AA)
private val RingBrush = Brush.linearGradient(listOf(Pink, Purple))

/** ring: true = unseen (colored), false = seen (gray), null = no ring */
@Composable
fun Avatar(p: Profile, size: Dp, ring: Boolean?) {
    val border = when (ring) {
        true -> Modifier.border(3.dp, RingBrush, CircleShape)
        false -> Modifier.border(3.dp, Color.Gray, CircleShape)
        null -> Modifier
    }
    Box(Modifier.size(size).then(border).padding(if (ring == null) 0.dp else 6.dp)) {
        AsyncImage(
            model = p.picUrl,
            contentDescription = p.username,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().clip(CircleShape).background(Color.LightGray),
        )
    }
}

fun countdown(sec: Long): String {
    val v = sec.coerceAtLeast(0)
    val h = v / 3600
    val m = (v % 3600) / 60
    val x = v % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, x) else "%02d:%02d".format(m, x)
}

@Composable
fun TopTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.statusBarsPadding().padding(16.dp),
    )
}

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
    }
}

// ---------------- Home ----------------

@Composable
fun HomeTab(session: Session, accountKey: String, refresh: Int, onOpen: (TrayUser) -> Unit) {
    var tray by remember { mutableStateOf<List<TrayUser>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(true) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis() / 1000) }

    LaunchedEffect(accountKey) {
        loading = true
        error = null
        runCatching { withContext(Dispatchers.IO) { Api.tray(session.cookie) } }
            .onSuccess { tray = it }
            .onFailure { error = it.message }
        loading = false
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis() / 1000
        }
    }

    val hurry = tray.filter { it.expiring > now }.sortedBy { it.expiring }.take(8)

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { TopTitle("Silent Story") }

        if (hurry.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Card(shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                s("hurry"), style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                            )
                            IconButton(onClick = { expanded = !expanded }) {
                                Icon(if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null)
                            }
                        }
                        if (expanded) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                items(hurry) { u ->
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.width(84.dp).clickable { onOpen(u) },
                                    ) {
                                        Avatar(u.profile, 76.dp, u.latest > session.viewed(u.profile.id))
                                        Text(
                                            u.profile.username, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                            style = MaterialTheme.typography.labelMedium,
                                        )
                                        Text(
                                            countdown(u.expiring - now),
                                            style = MaterialTheme.typography.labelMedium, color = Color.Gray,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (loading) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        } else if (tray.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(error ?: s("no_tray"), color = Color.Gray, modifier = Modifier.padding(8.dp))
            }
        }

        items(tray) { u ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable { onOpen(u) },
            ) {
                // 'refresh' is read here so rings update after returning from the viewer
                val unseen = u.latest > session.viewed(u.profile.id) && refresh >= 0
                Avatar(u.profile, 100.dp, unseen)
                Text(
                    u.profile.username, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
}

// ---------------- Search ----------------

@Composable
fun SearchTab(session: Session, onProfile: (Profile) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    fun go() {
        if (query.isBlank() || loading) return
        loading = true
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { Api.profile(query, session.cookie) } }
                .onSuccess { loading = false; onProfile(it) }
                .onFailure {
                    loading = false
                    Toast.makeText(ctx, it.message ?: "Error", Toast.LENGTH_LONG).show()
                }
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopTitle(s("search"))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text(s("search_hint")) },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                else IconButton(onClick = { go() }) { Icon(Icons.Default.ArrowForward, "Go") }
            },
        )
    }
}

// ---------------- Favorites ----------------

@Composable
fun FavoritesTab(session: Session, refresh: Int, onProfile: (Profile) -> Unit) {
    val list = remember(refresh) { session.pinned() }
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { TopTitle(s("favorites")) }
        if (list.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(s("no_fav"), color = Color.Gray, modifier = Modifier.padding(8.dp))
            }
        }
        items(list) { p ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable { onProfile(p) },
            ) {
                Avatar(p, 100.dp, null)
                Text(
                    p.username, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
}

// ---------------- Settings ----------------

@Composable
private fun SettingRow(icon: ImageVector, tint: Color, title: String, sub: String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(tint),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, null, tint = Color.White) }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
    }
}

@Composable
private fun ChoiceDialog(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } },
        title = { Text(title) },
        text = {
            Column {
                options.forEach { (key, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(key); onDismiss() }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = key == selected, onClick = { onPick(key); onDismiss() })
                        Text(label)
                    }
                }
            }
        },
    )
}

@Composable
fun SettingsTab(
    session: Session,
    accountKey: String,
    theme: String,
    lang: String,
    onTheme: (String) -> Unit,
    onLang: (String) -> Unit,
    onNav: (Overlay) -> Unit,
) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf("") }
    val active = remember(accountKey) { session.active }
    val count = remember(accountKey) { session.accounts().size }

    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 110.dp)) {
        item { TopTitle(s("settings")) }
        item {
            Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.clickable { onNav(Overlay.Accounts) }) {
                Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(64.dp).clip(CircleShape).background(Color.LightGray),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(40.dp)) }
                    Column(Modifier.weight(1f).padding(start = 16.dp)) {
                        Text(
                            active?.username ?: "-", style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(s("switch_account"), color = Color.Gray)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "$count ${if (count == 1) "account" else "accounts"}",
                            color = Color.White,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(Pink)
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                        )
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
        item {
            Card(shape = RoundedCornerShape(24.dp)) {
                SettingRow(Icons.Default.WorkspacePremium, Color(0xFF3B82F6), s("membership"), s("membership_sub")) {
                    onNav(Overlay.Membership)
                }
            }
        }
        item {
            Text("Promotions", color = Color.Gray, modifier = Modifier.padding(start = 8.dp, top = 20.dp, bottom = 8.dp))
            Card(shape = RoundedCornerShape(24.dp)) {
                SettingRow(Icons.Default.Star, Color(0xFFF59E0B), s("promo"), null) { onNav(Overlay.Viewers) }
            }
        }
        item {
            Spacer(Modifier.height(16.dp))
            Card(shape = RoundedCornerShape(24.dp)) {
                Column {
                    SettingRow(
                        Icons.Default.Language, Color(0xFF22C55E), s("language"),
                        if (lang == "hi") "हिन्दी" else "English",
                    ) { dialog = "lang" }
                    HorizontalDivider(Modifier.padding(start = 70.dp))
                    SettingRow(
                        Icons.Default.Brush, Color(0xFFF59E0B), s("appearance"),
                        s(
                            when (theme) {
                                "light" -> "theme_light"
                                "dark" -> "theme_dark"
                                else -> "theme_auto"
                            },
                        ),
                    ) { dialog = "theme" }
                }
            }
        }
        item {
            Spacer(Modifier.height(16.dp))
            Card(shape = RoundedCornerShape(24.dp)) {
                Column {
                    SettingRow(Icons.Default.Star, Color(0xFFF59E0B), s("rate"), s("rate_sub")) {
                        Toast.makeText(ctx, "Thank you!", Toast.LENGTH_SHORT).show()
                    }
                    HorizontalDivider(Modifier.padding(start = 70.dp))
                    SettingRow(Icons.Default.Share, Color(0xFF8B5CF6), s("tell"), s("tell_sub")) {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "Try Silent Story - watch and save stories privately.")
                        }
                        ctx.startActivity(Intent.createChooser(send, null))
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(16.dp))
            Card(shape = RoundedCornerShape(24.dp)) {
                Column {
                    SettingRow(Icons.Default.PrivacyTip, Color(0xFF64748B), s("privacy"), null) {
                        onNav(
                            Overlay.Info(
                                tr("privacy", lang),
                                "Silent Story keeps your Instagram login, pinned profiles and saved viewer lists only on " +
                                    "this device. Nothing is sent to any server except Instagram itself. " +
                                    "This app is not affiliated with or endorsed by Instagram.",
                            ),
                        )
                    }
                    HorizontalDivider(Modifier.padding(start = 70.dp))
                    SettingRow(Icons.Default.Description, Color(0xFFB45309), s("terms"), null) {
                        onNav(
                            Overlay.Info(
                                tr("terms", lang),
                                "This app is for personal use. It uses Instagram's unofficial web endpoints, which can " +
                                    "change or stop working at any time. Do not repost other people's stories without " +
                                    "their permission. Using it may go against Instagram's terms and you do so at your own risk.",
                            ),
                        )
                    }
                }
            }
        }
    }

    if (dialog == "lang") {
        ChoiceDialog(
            s("language"), listOf("en" to "English", "hi" to "हिन्दी"), lang, onLang,
        ) { dialog = "" }
    }
    if (dialog == "theme") {
        ChoiceDialog(
            s("appearance"),
            listOf("auto" to s("theme_auto"), "light" to s("theme_light"), "dark" to s("theme_dark")),
            theme, onTheme,
        ) { dialog = "" }
    }
}

// ---------------- Overlays: Membership, Accounts, Viewers, Info ----------------

@Composable
fun MembershipScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar(s("membership"), onBack)
        Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.padding(16.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text(s("premium_active"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                listOf(
                    "Saved story viewer list",
                    "HD downloads",
                    "Multiple Instagram accounts",
                    "No ads",
                ).forEach {
                    Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF22C55E))
                        Text(it, Modifier.padding(start = 12.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun InfoScreen(title: String, text: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar(title, onBack)
        Text(text, modifier = Modifier.padding(20.dp))
    }
}

@Composable
fun AccountsScreen(session: Session, onAdd: () -> Unit, onChanged: () -> Unit, onBack: () -> Unit) {
    var list by remember { mutableStateOf(session.accounts()) }
    var activeId by remember { mutableStateOf(session.active?.userId ?: "") }
    Column(Modifier.fillMaxSize()) {
        TopBar(s("accounts"), onBack)
        list.forEach { a ->
            Row(
                Modifier.fillMaxWidth().clickable {
                    session.activeId = a.userId; activeId = a.userId; onChanged()
                }.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = a.userId == activeId, onClick = {
                    session.activeId = a.userId; activeId = a.userId; onChanged()
                })
                Text(a.username, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = {
                    session.removeAccount(a.userId)
                    list = session.accounts()
                    activeId = session.active?.userId ?: ""
                    onChanged()
                }) { Icon(Icons.Default.Delete, "Remove") }
            }
        }
        Button(onClick = onAdd, modifier = Modifier.padding(16.dp)) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text(s("add_account"))
        }
    }
}

@Composable
fun ViewersScreen(session: Session, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val acc = session.active
    var list by remember { mutableStateOf(acc?.let { ViewerStore.load(ctx, it.userId) } ?: emptyList()) }
    val fmt = remember { SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()) }

    Column(Modifier.fillMaxSize()) {
        TopBar(s("viewers_title"), onBack)
        Text(
            "The app saves who views your stories about once an hour while your phone is online, " +
                "so the list stays after Instagram removes it.",
            style = MaterialTheme.typography.bodyMedium, color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        Row(Modifier.padding(16.dp)) {
            Button(onClick = {
                WorkManager.getInstance(ctx).enqueue(OneTimeWorkRequestBuilder<ViewerWorker>().build())
                Toast.makeText(ctx, "Checking in the background", Toast.LENGTH_SHORT).show()
            }) { Text(s("check_now")) }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = {
                list = acc?.let { ViewerStore.load(ctx, it.userId) } ?: emptyList()
            }) { Text("Refresh") }
        }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list) { st ->
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(
                                model = st.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).background(Color.LightGray),
                            )
                            Column(Modifier.padding(start = 12.dp)) {
                                Text(fmt.format(Date(st.takenAt * 1000)), fontWeight = FontWeight.SemiBold)
                                Text("${st.viewers.size} viewers", color = Color.Gray)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            st.viewers.joinToString(", ") { it.username },
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
        }
    }
}
