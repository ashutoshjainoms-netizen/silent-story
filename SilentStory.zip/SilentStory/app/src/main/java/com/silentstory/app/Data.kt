package com.silentstory.app

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

data class Profile(
    val id: String,
    val username: String,
    val fullName: String,
    val picUrl: String,
    val isPrivate: Boolean,
)

data class TrayUser(val profile: Profile, val latest: Long, val expiring: Long)

data class StoryItem(
    val id: String,
    val url: String,
    val thumb: String,
    val isVideo: Boolean,
    val takenAt: Long,
)

data class Highlight(val id: String, val title: String, val cover: String)

data class Account(val userId: String, val username: String, val cookie: String)

data class ViewerRec(val username: String, val fullName: String, val picUrl: String)

data class SavedStory(
    val storyId: String,
    val takenAt: Long,
    val thumb: String,
    val viewers: List<ViewerRec>,
)

/** Everything is stored on this device only. */
class Session(context: Context) {
    private val prefs = context.getSharedPreferences("silent_story", Context.MODE_PRIVATE)

    fun accounts(): List<Account> {
        val arr = JSONArray(prefs.getString("accounts", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Account(o.getString("userId"), o.getString("username"), o.getString("cookie"))
        }
    }

    private fun saveAccounts(list: List<Account>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("userId", it.userId).put("username", it.username).put("cookie", it.cookie))
        }
        prefs.edit().putString("accounts", arr.toString()).apply()
    }

    var activeId: String
        get() = prefs.getString("activeId", "") ?: ""
        set(v) = prefs.edit().putString("activeId", v).apply()

    val active: Account?
        get() {
            val l = accounts()
            return l.firstOrNull { it.userId == activeId } ?: l.firstOrNull()
        }

    val cookie: String get() = active?.cookie ?: ""

    fun addAccount(a: Account) {
        val l = accounts().filter { it.userId != a.userId } + a
        saveAccounts(l)
        activeId = a.userId
    }

    fun removeAccount(id: String) {
        val l = accounts().filter { it.userId != id }
        saveAccounts(l)
        if (activeId == id) activeId = l.firstOrNull()?.userId ?: ""
    }

    var theme: String
        get() = prefs.getString("theme", "auto") ?: "auto"
        set(v) = prefs.edit().putString("theme", v).apply()

    var lang: String
        get() = prefs.getString("lang", "en") ?: "en"
        set(v) = prefs.edit().putString("lang", v).apply()

    // latest story timestamp the user has opened inside this app, per profile
    fun viewed(userId: String): Long =
        JSONObject(prefs.getString("viewed", "{}")).optLong(userId, 0L)

    fun setViewed(userId: String, t: Long) {
        val o = JSONObject(prefs.getString("viewed", "{}"))
        o.put(userId, t)
        prefs.edit().putString("viewed", o.toString()).apply()
    }

    fun pinned(): List<Profile> {
        val arr = JSONArray(prefs.getString("pinned", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Profile(
                o.getString("id"), o.getString("username"), o.optString("fullName"),
                o.optString("picUrl"), o.optBoolean("isPrivate"),
            )
        }
    }

    fun isPinned(id: String) = pinned().any { it.id == id }

    fun togglePin(p: Profile) {
        val list = pinned().toMutableList()
        if (list.any { it.id == p.id }) list.removeAll { it.id == p.id } else list.add(p)
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("username", it.username)
                    .put("fullName", it.fullName).put("picUrl", it.picUrl)
                    .put("isPrivate", it.isPrivate),
            )
        }
        prefs.edit().putString("pinned", arr.toString()).apply()
    }
}

/** Saved viewer lists of your own stories, kept in a private file per account. */
object ViewerStore {
    private fun file(ctx: Context, acc: String) = File(ctx.filesDir, "viewers_$acc.json")

    fun load(ctx: Context, acc: String): List<SavedStory> {
        val f = file(ctx, acc)
        if (!f.exists()) return emptyList()
        val arr = JSONArray(f.readText())
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val vs = o.getJSONArray("viewers")
            SavedStory(
                o.getString("storyId"), o.optLong("takenAt"), o.optString("thumb"),
                (0 until vs.length()).map { j ->
                    val v = vs.getJSONObject(j)
                    ViewerRec(v.getString("username"), v.optString("fullName"), v.optString("picUrl"))
                },
            )
        }.sortedByDescending { it.takenAt }
    }

    fun merge(ctx: Context, acc: String, story: StoryItem, users: List<ViewerRec>) {
        val all = load(ctx, acc).toMutableList()
        val old = all.firstOrNull { it.storyId == story.id }
        val merged = ((old?.viewers ?: emptyList()) + users).distinctBy { it.username }
        all.removeAll { it.storyId == story.id }
        all.add(SavedStory(story.id, story.takenAt, story.thumb, merged))
        val arr = JSONArray()
        all.forEach { s ->
            val vs = JSONArray()
            s.viewers.forEach {
                vs.put(JSONObject().put("username", it.username).put("fullName", it.fullName).put("picUrl", it.picUrl))
            }
            arr.put(
                JSONObject().put("storyId", s.storyId).put("takenAt", s.takenAt)
                    .put("thumb", s.thumb).put("viewers", vs),
            )
        }
        file(ctx, acc).writeText(arr.toString())
    }
}

/**
 * Talks to Instagram's unofficial web endpoints using the user's own session.
 * These endpoints are undocumented and can change at any time.
 * Stories are only fetched; the "seen" request is never sent, so viewing stays anonymous.
 */
object Api {
    private const val APP_ID = "936619743392459"
    private const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    private val client = OkHttpClient()

    private fun get(url: String, cookie: String): JSONObject {
        val csrf = Regex("csrftoken=([^;]+)").find(cookie)?.groupValues?.get(1) ?: ""
        val req = Request.Builder().url(url)
            .header("Cookie", cookie)
            .header("User-Agent", UA)
            .header("X-IG-App-ID", APP_ID)
            .header("X-CSRFToken", csrf)
            .header("X-Requested-With", "XMLHttpRequest")
            .build()
        client.newCall(req).execute().use { res ->
            if (res.code == 401 || res.code == 403) throw IOException("Session expired. Log in again.")
            if (res.code == 429) throw IOException("Too many requests. Try again later.")
            if (!res.isSuccessful) throw IOException("Request failed (${res.code})")
            return JSONObject(res.body?.string() ?: "{}")
        }
    }

    fun username(userId: String, cookie: String): String =
        get("https://www.instagram.com/api/v1/users/$userId/info/", cookie)
            .getJSONObject("user").getString("username")

    fun profile(username: String, cookie: String): Profile {
        val u = username.trim().removePrefix("@")
        val json = get("https://www.instagram.com/api/v1/users/web_profile_info/?username=$u", cookie)
        val user = json.getJSONObject("data").optJSONObject("user") ?: throw IOException("User not found")
        return Profile(
            id = user.getString("id"),
            username = user.getString("username"),
            fullName = user.optString("full_name"),
            picUrl = user.optString("profile_pic_url_hd", user.optString("profile_pic_url")),
            isPrivate = user.optBoolean("is_private"),
        )
    }

    private fun parseItems(items: JSONArray?): List<StoryItem> {
        if (items == null) return emptyList()
        return (0 until items.length()).mapNotNull { i ->
            val it = items.getJSONObject(i)
            val thumb = it.optJSONObject("image_versions2")
                ?.optJSONArray("candidates")?.optJSONObject(0)?.optString("url") ?: ""
            val video = it.optJSONArray("video_versions")?.optJSONObject(0)?.optString("url")
            val url = video ?: thumb
            if (url.isBlank()) null
            else StoryItem(it.optString("pk", it.optString("id")), url, thumb, video != null, it.optLong("taken_at"))
        }
    }

    fun stories(userId: String, cookie: String): List<StoryItem> {
        val json = get("https://www.instagram.com/api/v1/feed/reels_media/?reel_ids=$userId", cookie)
        return parseItems(json.optJSONObject("reels")?.optJSONObject(userId)?.optJSONArray("items"))
    }

    fun highlights(userId: String, cookie: String): List<Highlight> {
        val json = get("https://www.instagram.com/api/v1/highlights/$userId/highlights_tray/", cookie)
        val tray = json.optJSONArray("tray") ?: return emptyList()
        return (0 until tray.length()).map {
            val o = tray.getJSONObject(it)
            Highlight(
                o.getString("id"), o.optString("title"),
                o.optJSONObject("cover_media")?.optJSONObject("cropped_image_version")?.optString("url") ?: "",
            )
        }
    }

    fun highlightItems(highlightId: String, cookie: String): List<StoryItem> {
        val json = get("https://www.instagram.com/api/v1/feed/reels_media/?reel_ids=$highlightId", cookie)
        return parseItems(json.optJSONObject("reels")?.optJSONObject(highlightId)?.optJSONArray("items"))
    }

    /** Accounts you follow that currently have stories. */
    fun tray(cookie: String): List<TrayUser> {
        val json = get("https://www.instagram.com/api/v1/feed/reels_tray/", cookie)
        val tray = json.optJSONArray("tray") ?: return emptyList()
        return (0 until tray.length()).mapNotNull { i ->
            val r = tray.getJSONObject(i)
            val u = r.optJSONObject("user") ?: return@mapNotNull null
            val latest = r.optLong("latest_reel_media")
            val exp = r.optLong("expiring_at", latest + 86400)
            TrayUser(
                Profile(
                    u.getString("pk"), u.getString("username"), u.optString("full_name"),
                    u.optString("profile_pic_url"), u.optBoolean("is_private"),
                ),
                latest, exp,
            )
        }
    }

    /** Viewers of one of YOUR OWN stories. Instagram removes this list after 24 hours. */
    fun viewers(mediaId: String, cookie: String): List<ViewerRec> {
        val json = get("https://www.instagram.com/api/v1/media/$mediaId/list_reel_media_viewer/", cookie)
        val arr = json.optJSONArray("users") ?: return emptyList()
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            ViewerRec(o.getString("username"), o.optString("full_name"), o.optString("profile_pic_url"))
        }
    }
}
