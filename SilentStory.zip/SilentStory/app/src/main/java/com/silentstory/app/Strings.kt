package com.silentstory.app

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf

val LocalLang = compositionLocalOf { "en" }

private val T: Map<String, Pair<String, String>> = mapOf(
    "home" to ("Home" to "होम"),
    "search" to ("Search" to "खोजें"),
    "favorites" to ("Favorites" to "पसंदीदा"),
    "settings" to ("Settings" to "सेटिंग्स"),
    "hurry" to ("Hurry Up!" to "जल्दी करें!"),
    "search_hint" to ("Search username" to "यूज़रनेम खोजें"),
    "no_stories" to ("No active stories." to "कोई एक्टिव स्टोरी नहीं।"),
    "no_tray" to ("No stories from people you follow right now." to "अभी आपके फॉलो किए लोगों की कोई स्टोरी नहीं।"),
    "no_fav" to ("Search a profile and tap the pin to add it here." to "प्रोफ़ाइल खोजें और पिन दबाकर यहाँ जोड़ें।"),
    "membership" to ("Membership" to "मेंबरशिप"),
    "membership_sub" to ("Manage premium access" to "प्रीमियम एक्सेस देखें"),
    "promo" to ("Story Viewers Won't Disappear" to "स्टोरी व्यूअर गायब नहीं होंगे"),
    "language" to ("Language" to "भाषा"),
    "appearance" to ("Appearance" to "रूप"),
    "rate" to ("Rate Us" to "रेटिंग दें"),
    "rate_sub" to ("Tell us how the app is doing" to "ऐप कैसा चल रहा है बताएं"),
    "tell" to ("Tell a Friend" to "दोस्त को बताएं"),
    "tell_sub" to ("Share this app" to "ऐप शेयर करें"),
    "privacy" to ("Privacy Policy" to "प्राइवेसी पॉलिसी"),
    "terms" to ("Terms of Use" to "उपयोग की शर्तें"),
    "switch_account" to ("Switch or add account" to "अकाउंट बदलें या जोड़ें"),
    "accounts" to ("Accounts" to "अकाउंट"),
    "add_account" to ("Add account" to "अकाउंट जोड़ें"),
    "theme_auto" to ("Automatic" to "ऑटोमैटिक"),
    "theme_light" to ("Light" to "लाइट"),
    "theme_dark" to ("Dark" to "डार्क"),
    "premium_active" to ("Premium is active" to "प्रीमियम चालू है"),
    "saved" to ("Saved to gallery" to "गैलरी में सेव हुआ"),
    "viewers_title" to ("Saved viewers" to "सेव किए व्यूअर"),
    "check_now" to ("Check now" to "अभी जांचें"),
    "new_stories" to ("New" to "नई"),
)

fun tr(key: String, lang: String): String {
    val p = T[key] ?: return key
    return if (lang == "hi") p.second else p.first
}

@Composable
fun s(key: String): String = tr(key, LocalLang.current)
