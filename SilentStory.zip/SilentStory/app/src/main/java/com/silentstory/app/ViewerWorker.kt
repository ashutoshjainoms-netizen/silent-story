package com.silentstory.app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Runs about once an hour. Reads the viewer list of your own active stories
 * and saves it on this device, because Instagram deletes it after 24 hours.
 */
class ViewerWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val acc = Session(applicationContext).active ?: return Result.success()
        return try {
            val stories = Api.stories(acc.userId, acc.cookie)
            for (story in stories) {
                val users = Api.viewers(story.id, acc.cookie)
                ViewerStore.merge(applicationContext, acc.userId, story, users)
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
